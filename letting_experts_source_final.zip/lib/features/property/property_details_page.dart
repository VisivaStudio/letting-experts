import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:ui';
import '../../core/models/property.dart';

class PropertyDetailsPage extends StatelessWidget {
  final Property property;

  const PropertyDetailsPage({super.key, required this.property});

  // Theme Colors
  static const Color lettingRed = Color(0xFFCE3132);
  static const Color expertBlack = Color(0xFF1C1C1C);

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xFF2C2C2C), // Dark Mode Background
      body: CustomScrollView(
        slivers: [
          // Hero Image Header
          SliverAppBar(
            expandedHeight: screenHeight * 0.45,
            pinned: true,
            backgroundColor: expertBlack,
            leading: Padding(
              padding: const EdgeInsets.all(8.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Container(
                    decoration: BoxDecoration(color: Colors.black.withAlpha(100)),
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                ),
              ),
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      decoration: BoxDecoration(color: Colors.black.withAlpha(100)),
                      child: IconButton(
                        icon: const Icon(Icons.favorite_border, color: Colors.white),
                        onPressed: () {},
                      ),
                    ),
                  ),
                ),
              )
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Hero(
                tag: 'image_${property.id}',
                child: CachedNetworkImage(
                  imageUrl: property.image,
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(color: Colors.grey.shade800),
                ),
              ),
            ),
          ),
          
          // Property Details Body
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                color: Color(0xFF1E1E1E),
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              transform: Matrix4.translationValues(0.0, -30.0, 0.0),
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header row (Price and Rating)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                property.title,
                                style: const TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(Icons.location_on, size: 16, color: lettingRed.withAlpha(200)),
                                  const SizedBox(width: 4),
                                  Text(
                                    property.location,
                                    style: TextStyle(color: Colors.grey.shade400, fontSize: 16),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          decoration: BoxDecoration(
                            color: lettingRed.withAlpha(30),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: lettingRed.withAlpha(100)),
                          ),
                          child: Text(
                            'R${property.rent.toStringAsFixed(0)}\n/mo',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: lettingRed,
                            ),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: 30),
                    
                    // Quick Amenities Bar
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildQuickStat(Icons.king_bed, '${property.bedrooms}', 'Beds'),
                        _buildStatDivider(),
                        _buildQuickStat(Icons.shower, '${property.bathrooms}', 'Baths'),
                        _buildStatDivider(),
                        _buildQuickStat(Icons.square_foot, '2,400', 'Sq.Ft'),
                      ],
                    ),
                    
                    const SizedBox(height: 30),
                    const Text(
                      'Description',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      property.description.isNotEmpty 
                        ? property.description 
                        : 'Experience unparalleled luxury in this exquisite ${property.type.toLowerCase()} located in the heart of ${property.location}. Featuring modern finishes, expansive living areas, and breathtaking views, this property is designed for those who appreciate the finer things in life. The neighborhood offers premium lifestyle amenities including curated retail and fine dining securely within reach.',
                      style: TextStyle(fontSize: 15, height: 1.6, color: Colors.grey.shade400),
                    ),
                    
                    const SizedBox(height: 30),
                    const Text(
                      'Premium Features',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    const SizedBox(height: 16),
                    // Features Grid
                    GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      childAspectRatio: 3,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      children: [
                        _buildFeaturePill(Icons.wifi, 'Fibre Ready'),
                        _buildFeaturePill(Icons.security, '24/7 Security'),
                        _buildFeaturePill(Icons.pool, 'Private Pool'),
                        _buildFeaturePill(Icons.local_parking, 'Secure Parking'),
                        _buildFeaturePill(Icons.pets, 'Pet Friendly'),
                        _buildFeaturePill(Icons.fitness_center, 'Gym Access'),
                      ],
                    ),
                    const SizedBox(height: 40), // Pad for sticky bottom bar
                  ],
                ),
              ),
            ),
          )
        ],
      ),
      // Sticky Bottom Action Bar
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        decoration: BoxDecoration(
          color: expertBlack,
          boxShadow: [
            BoxShadow(color: Colors.black.withAlpha(100), blurRadius: 30, offset: const Offset(0, -10)),
          ],
        ),
        child: SafeArea(
          child: Row(
            children: [
              // Chat IconButton
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF2C2C2C),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withAlpha(20)),
                ),
                child: IconButton(
                  icon: const Icon(Icons.chat_bubble_outline, color: Colors.white),
                  onPressed: () {},
                  padding: const EdgeInsets.all(16),
                ),
              ),
              const SizedBox(width: 16),
              // Main CTA Button
              Expanded(
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: lettingRed,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 10,
                    shadowColor: lettingRed.withAlpha(100),
                  ),
                  child: const Text(
                    'Book a Viewing',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickStat(IconData icon, String value, String label) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF2C2C2C),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withAlpha(10)),
          ),
          child: Icon(icon, color: Colors.grey.shade300, size: 24),
        ),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 16)),
        Text(label, style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
      ],
    );
  }

  Widget _buildStatDivider() {
    return Container(
      height: 40,
      width: 1,
      color: Colors.white.withAlpha(20),
    );
  }

  Widget _buildFeaturePill(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF2C2C2C),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withAlpha(15)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: lettingRed.withAlpha(200)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
